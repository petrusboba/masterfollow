<?php

$country = "62";
$nomor = "82112591423";

?>
